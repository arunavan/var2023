package com.adp.producerdemo;

import java.util.*;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableDiscoveryClient
@RestController
@RequestMapping("/producer")
public class ProducerdemoApplication {  //http://localhost:8702/producer/courses
	public static void main(String[] args) {
		SpringApplication.run(ProducerdemoApplication.class, args);
	}
	
	@GetMapping(value="/courses")
		public List<String> getCourses(){
		List<String> list=Arrays.asList("Java","JE2EE","oralce","Microservices");
		return list;
	}

	/*
	 * @Bean public SecurityWebFilterChain securityWebFilterChain(
	 * ServerHttpSecurity http) { return http.authorizeExchange()
	 * .pathMatchers("/actuator/**").permitAll() .anyExchange().authenticated()
	 * .and().build(); }
	 */
}
