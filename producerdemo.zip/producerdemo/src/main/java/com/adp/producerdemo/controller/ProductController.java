package com.adp.producerdemo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	
	@GetMapping("/products")
	public List<String> getProducts() {
		return Arrays.asList("java","j2ee","oracle");
	}
	@PostMapping("/products")
	public String getProducts1() {
		return "added";
	}
	@PutMapping("/products")
	public String getProducts2() {
		return "updated";
	}
	@DeleteMapping("/products")
	public String getProducts3() {
		return "deleted";
	}

}
