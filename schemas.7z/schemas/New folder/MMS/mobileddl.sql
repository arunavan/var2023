create database mobile;

use mobile;

-- Distributor Info table

create table Distributor
(
Distributor_ID varchar(10) ,
Distributor_Name varchar(20),
Address varchar(100),
Mobilenumber int (10),
Email varchar(30), 
constraint pk_distributor primary key(Distributor_ID) );

-- Mobile master table
create table Mobile_Master
(
IME_No varchar(10), Model_Name varchar(20), Manufacturer varchar(20), Date_Of_Manufac date,
Warranty_in_Years int(10), Price decimal(7,2), Distributor_ID varchar(10),
constraint pk_ime primary key(IME_No),foreign key(Distributor_ID) references Distributor(Distributor_ID)
);

-- Mobile specification table
create table Mobile_Specification
(IME_No varchar(10), Dimension varchar(20), Weight varchar(20),Display_Type varchar(20), Display_Size varchar(20),Internal_mem_in_MB int(10),Memory_Card_Capacity_GB int(10), Network_3G varchar(5),GPRS varchar(5), EDGE varchar(5), Bluetooth varchar(5),
Camera varchar(5), Camera_Quality varchar(5) , OS varchar(20), Battery_Life_Hrs int(10) ,constraint fk_ime foreign key(IME_No) references Mobile_Master(IME_No));

-- Customer Information table
create table Customer_Info
(Customer_ID varchar(10),Customer_Name varchar(20),Address varchar(100),Mobile long,Email varchar(30),constraint pk_customer primary key(Customer_ID));

-- Sales information table
create table Sales_Info
(SalesId int(10),Sales_Date date,IME_No varchar(10),Price int(10),Discount int(10),Net_Amount int(10),Customer_ID varchar(10),constraint fk_sales primary key(SalesId),foreign key(Customer_ID) references Customer_Info(Customer_ID), foreign key(IME_No) references Mobile_Master(IME_No));

