-- Write a query to display the Department_Name, Department_Location whose number of employees 
-- are more than or equal to 4

select b.department_name,b.department_location,count(b.department_name) from PMS_DEPARTMENT_DETAILS b 
join  PMS_MANAGER_DETAILS a on a.department_id=b.department_id group by a.department_id having count(b.department_name)>=4;