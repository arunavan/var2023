// #docregion
import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit {
  data: Array<Map<string, string>>;
  headers: Array<string>;
  filters: Array<Ifilter>;

  constructor() {

  }
  ngOnInit() {

    this.data = new Array(
      new Map([["id", "1"], ["name", "harish"], ["age", "20"], ["grade", "A"]]),
      new Map([["id", "2"], ["name", "suresh"], ["age", "23"], ["grade", "B"]]),
      new Map([["id", "3"], ["name", "Anil"], ["age", "25"], ["grade", "C"]]),
      new Map([["id", "4"], ["name", "prem"], ["age", "24"], ["grade", "D"]])
    );
    this.headers = Array.from((this.data[0]).keys()); //to print headers 
    this.filters = new Array({ header: "id", filter: "" }, { header: "name", filter: "" }, { header: "age", filter: "" }, { header: "grade", filter: "" })

  }

}
export interface Ifilter {
  header: string;
  filter: string;
}
