import { BrowserModule }        from '@angular/platform-browser';
import { NgModule }             from '@angular/core';
import { AppComponent }         from './app.component';
import{FilterPipe} from './custom.pipe'
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [ BrowserModule ,FormsModule],

  declarations: [ AppComponent,FilterPipe],
  bootstrap: [ AppComponent ]
})
export class AppModule {
  constructor() {}
}
