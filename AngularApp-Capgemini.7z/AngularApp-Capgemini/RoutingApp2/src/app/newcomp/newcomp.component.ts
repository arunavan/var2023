import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcomp',
  templateUrl: './newcomp.component.html',
  styleUrls: ['./newcomp.component.css']
})
export class NewcompComponent implements OnInit {

  newcomp:string ="This is Contact US Page ";
  constructor() { }

  ngOnInit(): void {
  }

}
