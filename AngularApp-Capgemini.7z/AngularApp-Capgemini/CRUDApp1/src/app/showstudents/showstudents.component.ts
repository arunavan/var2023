import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showstudents',
  templateUrl: './showstudents.component.html',
  styleUrls: []
})
export class ShowstudentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
