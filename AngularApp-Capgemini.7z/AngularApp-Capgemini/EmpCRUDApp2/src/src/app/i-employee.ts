export interface IEmployee {
    id: number;
    empName: string;
    empEmail: string;
    empPhone: string;
}
