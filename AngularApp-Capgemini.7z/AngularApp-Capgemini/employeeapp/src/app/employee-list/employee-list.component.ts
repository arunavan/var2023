import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeService } from '../employeeservice';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  service:EmployeeService;

  constructor(service:EmployeeService) {
    this.service=service;
   }

  employees:Employee[]=[];

  delete(id:number){
    this.service.delete(id);
    this.employees=this.service.getEmployees();
  }

  ngOnInit() {
  this.service.fetchEmployees();
  this.employees=this.service.getEmployees();
  
  }

}


