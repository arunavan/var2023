import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeeupdate',
  templateUrl: './employeeupdate.component.html',
  styleUrls: ['./employeeupdate.component.css']
})
export class EmployeeupdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
