import { ChangeTextDirective } from './change-text.directive';

describe('ChangeTextDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeTextDirective();
    expect(directive).toBeTruthy();
  });
});
