/*
import { Component,ViewChild, AfterViewInit } from '@angular/core';
import { HelloComponent } from './hello/hello.component';
@Component({
  selector: 'app-root',
  template: `
  {{ msg }}  <br>
    <app-hello [childMessage]="parentMessage"></app-hello>
    <br>
    <app-login  [loginData]="loginMessage" > </app-login>
    
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  parentMessage = " using @input Message from Parent to Child ";
  loginMessage="My Login credentials Akash & 123456 "
  msg="This is Parent message"
  constructor() { }
 
}
*/

import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: `
    Message reveived from Child : {{message}}
    <app-child (messageEvent)="receiveMessage($event)"></app-child>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor() { }
  message:string;
  receiveMessage($event:any) {
    this.message = $event
  }
}
