/*import { Component, Input } from '@angular/core';
@Component({
  selector: 'app-hello',
  template: ` <p>hello works!</p>
      Say {{ childMessage }}
      <br>
      {{  cmsg }}
  `,
  styleUrls: ['./hello.component.css']
})
export class HelloComponent {
  @Input() childMessage: string;  //null
  cmsg="Child message"
  constructor() { } 
}
*/

import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
      <button (click)="sendMessage()">Send Message</button>
  `,
  styleUrls: ['./hello.component.css']
})
export class HelloComponent {

  message: string = "Welcome to Angular Training! using @output -Child to Parent"

  @Output() messageEvent = new EventEmitter<string>();

  constructor() { }

  sendMessage() {
    this.messageEvent.emit(this.message)
  }
}

