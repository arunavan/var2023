import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-login',
 // templateUrl: './login.component.html',
 template: `
     
      <br><hr>
      {{ loginData }}
  `,
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @Input() loginData: string;
  constructor() { }

  ngOnInit(): void {
  }

}
