package com.adp.batch3sampleprojectrepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch3SampleprojectRepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Batch3SampleprojectRepoApplication.class, args);
	}

}


//sonar token :924f27e70c7d1145f7cee87dc5a67e340ab2d0a9


//VN docker command to run container
//docker image ls

//to run at docker command prompt in VM

//docker container run --name 691bfd3c4a54 -p 8086:8086 -d 691bfd3c4a54