package com.adp.batch3sampleprojectrepo;

public class Sum {
	public Sum() {
	}
	public int add(int a,int b) {
		return a+b;
	}
	public int diff(int a,int b,int c) {
		return a-(b+c);
	}
	public String getMessage(){
	return "Welcome";
	}
}
