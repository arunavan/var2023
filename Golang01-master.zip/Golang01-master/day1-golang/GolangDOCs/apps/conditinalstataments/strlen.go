package main  
import "fmt"  
func main() {  
   str := "I love my country"  
   fmt.Println(len(str))  
} 
