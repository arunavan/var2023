# Example 2

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v2/*.go
```
