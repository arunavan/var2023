# Example 7

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v7/*.go
```
