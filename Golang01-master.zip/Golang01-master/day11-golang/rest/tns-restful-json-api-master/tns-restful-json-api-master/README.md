# JSON Restful JSON API

This code repository hosts the examples used in the following [The New Stack](http://thenewstack.io/make-a-restful-json-api-go/) article.


## Running Examples

To run exmaples, from the root of this project (change the version as needed):

```sh
# Run example 1
go run ./v1/*.go
```

```sh
# Run example 2
go run ./v2/*.go
```

