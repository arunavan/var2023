# Example 6

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v6/*.go
```
