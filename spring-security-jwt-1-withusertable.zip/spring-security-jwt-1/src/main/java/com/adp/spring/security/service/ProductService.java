package com.adp.spring.security.service;

import java.util.List;

import com.adp.spring.security.dto.Product;
import com.adp.spring.security.entity.UserInfo;

public interface ProductService {
	public void loadProductsFromDB();
	public List<Product> getAllProducts();
	public Product getProductById(int id);
	
	public String addUser(UserInfo userInfo);
}