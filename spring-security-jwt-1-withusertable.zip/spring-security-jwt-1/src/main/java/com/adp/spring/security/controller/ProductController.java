package com.adp.spring.security.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adp.spring.security.dto.AuthRequest;
import com.adp.spring.security.dto.Product;
import com.adp.spring.security.entity.UserInfo;
import com.adp.spring.security.service.JwtService;
import com.adp.spring.security.service.ProductService;

@RestController
@RequestMapping("api/v1")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
    private AuthenticationManager authenticationManager;
	
	//http://localhost:8082/api/v1/products/home
//	@GetMapping("/products/home")
//	public String sayWelcome() {
//		return "Welcome, this end-point is not secure";
//	}
	
	
	//http://localhost:8082/api/v1/users/new
	@PostMapping("/users/new")
	public String addNewUser(@RequestBody UserInfo userInfo) {
		return productService.addUser(userInfo);
	}
	
	
	@GetMapping("/products/admin")
//	@PreAuthorize("hasRole('ADMIN')")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
//	@PreAuthorize("hasRole('USER')")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/products/user/{id}")
	public Product getProductById(@PathVariable Integer id) {
		return productService.getProductById(id);
	}
	
	@PostMapping("/products/authenticate")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
        if (authentication.isAuthenticated()) {
            return jwtService.generateToken(authRequest.getUsername());
        } else {
            throw new UsernameNotFoundException("invalid user request !");
        }


    }
	
}
