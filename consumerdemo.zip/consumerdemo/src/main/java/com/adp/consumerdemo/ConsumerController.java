package com.adp.consumerdemo;
import java.util.List;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
@RequestMapping("/consumer")
public class ConsumerController { //localhost:8092/consumer/courses
    @Autowired 
	DiscoveryClient discoveryClient;
    
 //   @Autowired 
 //   SimpleClient simpleClient;
 
    
    @GetMapping("/courses")
  //@Retry(name="producer", fallbackMethod="sendDummyData")
  //	@CircuitBreaker(name="producer", fallbackMethod="sendDummyData")
  
	 public String getCources() {                  // http://localhost:8770/consumer/courses
           List<ServiceInstance> siList = discoveryClient.getInstances("PRODUCER");
           ServiceInstance si = siList.get(0);
            String url = si.getUri() +"/producer/courses";
           RestTemplate rt = new RestTemplate();
         String response = rt.getForObject(url, String.class);
          System.out.println("using discovery client"+ response);
            return response;
      }
    /*
    @GetMapping("/fiegn")   //http://localhost:8770/consumer/fiegn
    public List<String> getNewCourses() {
    	System.out.println("---Fiegn Client----");
		//return  new ArrayList<String>(); 
		return simpleClient.getData();
    }
    
  	

  	public String sendDummyData(Exception e) {
  		return "Producer is unvailable,please go for other option";
  	}
    
 */
}
