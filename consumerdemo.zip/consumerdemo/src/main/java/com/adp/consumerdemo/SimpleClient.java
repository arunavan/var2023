package com.adp.consumerdemo;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.ws.rs.core.MediaType;

@FeignClient(name = "fiegn-consumer", url = "http://localhost:8091/producer")
@LoadBalancerClient(name = "consumer",configuration=LoadBalancerConfiguration.class)
public interface SimpleClient {
    @GetMapping("/courses")
    List<String> getData();
    
}