package com.adp.consumerdemo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


//import com.netflix.appinfo.InstanceInfo;

import reactor.core.publisher.Mono;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;


@SpringBootApplication
@EnableDiscoveryClient
//@EnableFeignClients
public class ConsumerdemoApplication { //localhost:8770     ->console output
	  public static void main(String[] args) {
	    SpringApplication.run(ConsumerdemoApplication.class, args);
   	//blocking api
		RestTemplate restTemplate = new RestTemplate();
		String response=null;
		try {
		 response = restTemplate.getForObject("http://localhost:8091/producer/courses", String.class);
							
		} catch (Exception ex) {
		System.out.println(ex);
		}
		System.out.println("Rest Template.....");
		System.out.println(response);
		
	  }
	  
	// Default Configuration for Resilience4JCircuitBreakerFactory
	/*
	 * @Bean public Customizer<Resilience4JCircuitBreakerFactory>
	 * defaultCustomizer() { return factory -> factory.configureDefault(id -> new
	 * Resilience4JConfigBuilder(id)
	 * .timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.
	 * ofSeconds(4)).build())
	 * .circuitBreakerConfig(CircuitBreakerConfig.ofDefaults()).build()); }
	 * 
	 * // Default Configuration for ReactiveResilience4JCircuitBreakerFactory
	 * 
	 * @Bean public Customizer<ReactiveResilience4JCircuitBreakerFactory>
	 * defaultReactiveCustomizer() { return factory -> factory.configureDefault(id
	 * -> new Resilience4JConfigBuilder(id)
	 * .circuitBreakerConfig(CircuitBreakerConfig.ofDefaults())
	 * .timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.
	 * ofSeconds(4)).build()).build()); }
	 */
		
	}


