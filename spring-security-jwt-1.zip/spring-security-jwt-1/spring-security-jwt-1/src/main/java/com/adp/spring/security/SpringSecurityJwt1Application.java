package com.adp.spring.security;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.servlet.DispatcherServlet;




/*
 * 
 * Run in postman, post method, http://localhost:8082/authenticate
 * you will get jwt token, copy and paste in https://jwt.io/ to
 * decode the token
 * 
 * 
 * http://localhost:8082/api/v1/products/authenticate
 * {
        
        "name": "trainer",
       "password":"trainer@123"
        
    }
 * 
 */
 
@SpringBootApplication
//@EnableJpaRepositories(basePackages = "com.adp.spring.security.repository")
//@EntityScan(basePackages = "com.adp.spring.security.entity")
//@CrossOrigin(origins = "http://localhost:8082")
public class SpringSecurityJwt1Application {
	


	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityJwt1Application.class, args);
	}

}
