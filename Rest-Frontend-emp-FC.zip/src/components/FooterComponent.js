import React from 'react'

const FooterComponent = () => {
    return (
        <div>
            <footer className = "footer">
                 <span className="text-muted"><h6 align='center'>All Rights Reserved 2023 @ADP</h6></span>
            </footer>
        </div>
    )
}

export default FooterComponent