
import './App.css';
import EmployeeComponent from './EmployeeComponent';

function App() {
  return (
    <div className="App">
       <EmployeeComponent />
    </div>
  );
}

export default App;
