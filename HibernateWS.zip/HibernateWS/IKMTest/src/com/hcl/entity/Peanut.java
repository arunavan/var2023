package com.hcl.entity;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.annotations.IndexColumn;



@Entity
public class Peanut {
@Id
@Column (name= "peanut_id")
private String id;
@Column private BigDecimal price;
@OneToMany(cascade=CascadeType.ALL)
@JoinColumn(name="peanut_id")
@IndexColumn(name="idx")
private List<Walnut> walnuts;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public BigDecimal getPrice() {
	return price;
}
public void setPrice(BigDecimal price) {
	this.price = price;
}
public List<Walnut> getWalnuts() {
	return walnuts;
}
public void setWalnuts(List<Walnut> walnuts) {
	this.walnuts = walnuts;
}



}

