package com.hcl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Walnut{
@Id
@Column (name= "walnut_id")
private String id;
@ManyToOne
@JoinColumn(name="peanut_id", insertable=false, updatable=false, nullable=false)
private Peanut peanut;

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public Peanut getPeanut() {
	return peanut;
}
public void setPeanut(Peanut peanut) {
	this.peanut = peanut;
}


}
