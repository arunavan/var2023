package com.hcl.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Peanut;
import com.hcl.entity.Walnut;

public class One_To_Many_Bidirectional {

	public static void main(String[] args) {
		
		Session session= HibernateUtil.getSessionFactory().openSession();
		
		Walnut walnut1 = new Walnut();
		Walnut walnut2 = new Walnut();
		Walnut walnut3 = new Walnut();
		
		List<Walnut> walnuts = new ArrayList<Walnut>();
		walnuts.add(walnut1);
		walnuts.add(walnut1);
		walnuts.add(walnut1);
		
		Peanut peanut = new Peanut();
		peanut.setPrice(new BigDecimal(100));
		
		walnut1.setId("101");
		walnut1.setPeanut(peanut);
		walnut2.setId("102");
		walnut2.setPeanut(peanut);
		walnut3.setId("103");
		walnut3.setPeanut(peanut);
		
		peanut.setId("1");
		peanut.setWalnuts(walnuts);
		
		session.beginTransaction();
		try{
			
			session.save(walnut1);
			session.save(walnut2);
			session.save(walnut3);
			
			
			session.getTransaction().commit();
			System.err.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		

	}

}
