package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hcl.entity.Employee;

public class HibernateTest {
	
	private static final SessionFactory SESSION_FACTORY;
	
	static{
		
		try {
			SESSION_FACTORY = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Session Factory could not be created." + ex);
			throw new ExceptionInInitializerError();
		}		
	}
	
	
	

	public static SessionFactory getSessionFactory() {
		return SESSION_FACTORY;
	}




	public static void main(String[] args) {
		
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		Employee employee1 = new Employee();
		employee1.setEmployeeId(1);
		employee1.setEmployeeName("Sriram1");
		
		Employee employee2 = new Employee();
		employee2.setEmployeeId(2);
		employee2.setEmployeeName("Ram1");
		
		
		try{
			
			session.save(employee1);
			session.save(employee2);
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		
	}

}
