package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.Cart;
import com.hcl.entity.Item;

public class HibernateTest {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
		 Session session = sessionFactory.openSession();
		 session.beginTransaction();  
		 
		 	Item iphone = new Item();
	        iphone.setPrice(100);
	        iphone.setDescription("iPhone");
	         
	        Item ipod = new Item();
	        ipod.setPrice(50); 
	        ipod.setDescription("iPod");
	        
	        Cart cart1 = new Cart();
	        cart1.setTotal(200);
	        
	        Cart cart2 = new Cart();
	        cart2.setTotal(300);
	        
	        Set<Item>items = new HashSet<Item>();
	        items.add(iphone);
	        items.add(ipod);
	        
	        Set<Cart> cartSet = new HashSet<Cart>();
	        cartSet.add(cart1);
	        cartSet.add(cart2);
	        
	        iphone.setCarts(cartSet);
	        ipod.setCarts(cartSet);
	        
	        cart1.setItems(items);
	        cart2.setItems(items);
	        
	        session.save(iphone);
	        session.save(ipod);
		 
		 
         
	     session.getTransaction().commit();  
	          
	     session.close();  
		 

	}

}
