package com.hcl.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateTest {

	private static final SessionFactory SESSION_FACTORY;

	static {

		try {
			SESSION_FACTORY = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Session Factory could not be created." + ex);
			throw new ExceptionInInitializerError();
		}

	}

	public static SessionFactory getSessionFactory() {
		return SESSION_FACTORY;
	}

	public static void main(String[] args) {
		
		Session session = getSessionFactory().openSession();
		
		Employee employee = new Employee();
		employee.setEmployeeName("employee1");
		session.beginTransaction();
		try{
		session.save(employee);
		session.getTransaction().commit();
		
		System.out.println("Data inserted successfully");
		}catch(HibernateException ex){
			ex.printStackTrace();
		}finally{
			if (session != null) {
				session.close();
			}
		}
	}

}
