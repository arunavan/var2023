package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.Group;
import com.hcl.entity.User;

public class HibernateTest {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
		 Session session = sessionFactory.openSession();
		 session.beginTransaction();  
		 
		 Group groupAdmin = new Group("Administrator Group");
	     Group groupGuest = new Group("Guest Group");	
		 
	     User user1 = new User("Tom", "tomcat", "tom@codejava.net");
	     User user2 = new User("Mary", "mary", "mary@codejava.net");
	     
	     Set<User> users = new HashSet<User>();
	     users.add(user1);
	     users.add(user2);
	     
	     Set<Group>groups = new HashSet<Group>();
	     groups.add(groupAdmin);
	     groups.add(groupGuest);
	     
	     groupAdmin.setUsers(users);
	     groupGuest.setUsers(users);
	     
	     user1.setGroups(groups);
	     user2.setGroups(groups);
	     
	     session.save(groupAdmin);
	     session.save(groupGuest);
	     
         
	     session.getTransaction().commit();  
	          
	     session.close();  
		 

	}

}
