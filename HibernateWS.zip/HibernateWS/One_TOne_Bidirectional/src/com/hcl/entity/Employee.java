package com.hcl.entity;
import javax.persistence.*;
import java.util.Date;

@Entity
public class Employee {
	@Id
	private int e_code;
	private String ename;
	private double sal;
	private Date joindate;
	
	@OneToOne(mappedBy ="employees")
	private Department dept;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
		public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	
	public int getE_code() {
		return e_code;
	}
	public void setE_code(int e_code) {
		this.e_code = e_code;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Date getJoindate() {
		return joindate;
	}
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}

}
