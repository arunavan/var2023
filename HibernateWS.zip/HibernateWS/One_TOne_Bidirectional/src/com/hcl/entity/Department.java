package com.hcl.entity;
import javax.persistence.*;

@Entity
public class Department {
	@Id
	private int deptno;
	private String deptname;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="e_code")
	private Employee employees;
	
	public Employee getEmployees() {
		return employees;
	}
	public void setEmployees(Employee employees) {
		this.employees = employees;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

}
