package com.hcl.entity;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;




public class Emp_Dept_Manage {

	public void insertEmp(int code,String name,double sal){
		SessionFactory sf=null;
	  Session session=null;
	  Transaction tr=null;
	  try{
		  sf=HibernateUtil.getSessionFactory();
		  session=sf.openSession();
		   tr=session.beginTransaction();
		  Employee emp=new Employee();
		  emp.setE_code(code);
		  emp.setEname(name);
		  emp.setJoindate(new Date());
		  emp.setSal(sal);
		  session.save(emp);
		  tr.commit();
	 }
	 
	 catch(Exception e){
		 System.out.println("Error with insert block");
		 tr.rollback();
		 session.close();
	 }
	}
	 public void insertDept(String name,int code,int empcode){
			SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		  try{
			  sf=HibernateUtil.getSessionFactory();
			  session=sf.openSession();
			   tr=session.beginTransaction();
			   Employee emp=(Employee)session.load(Employee.class,new Integer(empcode));
			   Department dept=new Department();
			   dept.setDeptname(name);
			   dept.setDeptno(code);
			   dept.setEmployees(emp);
			  	 session.save(dept);
			  tr.commit();
			 }
		 
		 catch(Exception e){
			 System.out.println(e+"Error with insert block");
			 tr.rollback();
			 session.close();
		 }
	 }
		 
}
