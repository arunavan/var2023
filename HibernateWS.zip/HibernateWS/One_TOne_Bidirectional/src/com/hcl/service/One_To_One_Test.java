package com.hcl.service;

import com.hcl.entity.Emp_Dept_Manage;

public class One_To_One_Test {

	public static void main(String[] args) {
		 Emp_Dept_Manage ed=new  Emp_Dept_Manage();
		  ed.insertEmp(10,"Smith",4500.00);
		  ed.insertEmp(20,"Sam",4500.00);
		  ed.insertEmp(30,"Samule",4500.00);
		  ed.insertDept("Accounts",30,10);
		  ed.insertDept("Sales",40,20);

	}

}
