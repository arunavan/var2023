package jpqlpack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import entity.Educator;

public class Tester {

	/**
	 * @param args
	 */
	
	

	
	public static void main(String[] args) 
	{
		System.out.println("Enter your choice ");
		
		int choice=Integer.parseInt(acceptString());
		if(choice==1)
		{
		// TODO Auto-generated method stub
		System.out.println(" view all the Records for the educators");
		Service s=new Service();
		List<Educator> educatorList=s.viewAllRecords();
		for(Educator edu:educatorList)
		{
			System.out.println("EducatorId :	"+edu.getEducatorId()+"name :	"+edu.getEducatorName());
		}
		}
		if(choice==2)
		{
			System.out.println("view records for a selected Employee and few selected columns");
			System.out.println("enter the employee id to view data");
			int empId=Integer.parseInt(acceptString());
			Service s=new Service();
			List<Object> empList=s.viewSelectedRecords(empId);
			         System.out.println("name	"+"\t"+"	Salary");
			   for(int i=0;i<empList.size();i++)
		        {
		        	Object [] objarray=(Object[]) empList.get(i);
		        	    String name=(String) objarray[0];
		        	   float sal=(Float)objarray[1];
		        	    System.out.println(name+"\t\t\t"+sal);
		        	      
		        
		        	
		        }
		}
		

	}
	public static String acceptString() {
		// the return variable initialization
		String stringData = null;
		BufferedReader input = null;
		try {
			// chaining the streams
			input = new BufferedReader(new InputStreamReader(System.in));
			// reading data from the reader
			stringData = input.readLine();
		} catch (IOException ioException) {
			// System.out.println("Error in accepting data.");
		} finally {
			input = null;
		}
		return stringData;
	}
}
