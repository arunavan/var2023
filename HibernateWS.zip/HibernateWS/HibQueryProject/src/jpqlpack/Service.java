package jpqlpack;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import entity.Educator;

public class Service {
	private static final SessionFactory sessionFactory;

	static {

		try {

			sessionFactory = new AnnotationConfiguration().configure()
					.buildSessionFactory();

		} catch (Throwable ex) {

			System.err.println("Initial SessionFactory creation failed." + ex);

			throw new ExceptionInInitializerError(ex);

		}

	}

	public List<Educator> viewAllRecords() {
		List<Educator> educatorList = null;
		Session ses = sessionFactory.openSession();
		try {
			Query q = ses.createQuery("from Educator e");
			//q.setCacheable(true);

			educatorList = q.list();
			if (educatorList.isEmpty()) {
				System.out.println("List is empty");
			}

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return educatorList;
	}

	public List<Object> viewSelectedRecords(int employeeId) {
		List<Object> employeeList = null;
		// TODO Auto-generated method stub
		Session ses = sessionFactory.openSession();
		try {
			Query q = ses
					.createQuery("select e.empName,e.eSal from Employee e where e.empId=:data");
			q.setParameter("data", employeeId);
			employeeList = q.list();
			if (employeeList.isEmpty()) {
				System.out.println("List is empty");
			}

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return employeeList;

	}

}
