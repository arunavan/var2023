package entity;

	import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

	@Entity
	
	public class Educator{
	@Id
	@Column(name="educator_id")
	@GeneratedValue
	private Long educatorId;

	@Column(name="educator_name")
	private String educatorName ;
	
	
	public Long getEducatorId() {
		return educatorId;
	}

	public void setEducatorId(Long educatorId) {
		this.educatorId = educatorId;
	}

	public String getEducatorName() {
		return educatorName;
	}

	public void setEducatorName(String educatorName) {
		this.educatorName = educatorName;
	}

	
	public Educator(String educatorName) {
	this.educatorName = educatorName;
	}

	public Educator() {
	}

	
	}

	


