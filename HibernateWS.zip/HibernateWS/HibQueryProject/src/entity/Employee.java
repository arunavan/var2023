package entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;
@Entity

public class Employee 
{
	@Id
@GenericGenerator(name="generator", strategy="increment")
	
    @GeneratedValue(generator="generator")
    @Column(length=10,nullable=false)
	private int empId;
	@Column(length=20,nullable=false)
	private String empName;
	@Column(length=10,nullable=false)
	private float eSal;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float geteSal() {
		return eSal;
	}
	public void seteSal(float eSal) {
		this.eSal = eSal;
	}
	

}
