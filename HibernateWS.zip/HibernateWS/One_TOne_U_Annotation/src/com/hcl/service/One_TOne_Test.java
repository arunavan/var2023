package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.LaptopBag;
import com.hcl.entity.Scholar;

public class One_TOne_Test {

	public static void main(String[] args) {
	
		Session session=HibernateUtil.getSessionFactory().openSession();
		LaptopBag bag1= new LaptopBag();
		bag1.setBagId(1);
		bag1.setColor("black");
		
		Scholar scholar1 = new Scholar();
		scholar1.setScholarId(1001);
		scholar1.setScholarName("Ram");
		scholar1.setBag(bag1);
		
		Scholar scholar2 = new Scholar();
		scholar2.setScholarId(1002);
		scholar2.setScholarName("Sriram");
		scholar2.setBag(bag1);
		
		session.beginTransaction();
		
		try{
			session.save(scholar1);
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		

	}

}
