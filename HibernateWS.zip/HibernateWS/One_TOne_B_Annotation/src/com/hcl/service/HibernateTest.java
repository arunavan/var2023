package com.hcl.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.Author;
import com.hcl.entity.Biography;

public class HibernateTest {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
		 Session session = sessionFactory.openSession();
		 session.beginTransaction();  
		 
		 Author author = new Author();
		 author.setName("O. Henry");
		 
		 Biography biography = new Biography();
		
		 biography.setInformation("William Sydney Porter  better known as O. Henry...");
		 
		 author.setBiography(biography);
		 biography.setAuthor(author);
		 
		 session.save(author);  
         
	     session.getTransaction().commit();  
	          
	     session.close();  
		 

	}

}
