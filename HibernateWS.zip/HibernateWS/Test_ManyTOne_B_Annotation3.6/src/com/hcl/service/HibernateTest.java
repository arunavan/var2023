package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.CentreHead;
import com.hcl.entity.Staff;

public class HibernateTest {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
		 Session session = sessionFactory.openSession();
		 session.beginTransaction();  
		 
		 CentreHead centreHead= new CentreHead();
		 centreHead.setC_name("Sridevi");
		 centreHead.setCentre_name("Hyderabad");
		 
		 Staff staff1 = new Staff();
		 staff1.setS_name("Uttam");
		 staff1.setSpecialization("Java");
		 staff1.setCh(centreHead);
		 
		 Staff staff2 = new Staff();
		 staff2.setS_name("Ismile");
		 staff2.setSpecialization("C++");
		 staff2.setCh(centreHead);
		 
		 Staff staff3 = new Staff();
		 staff3.setS_name("Balaji");
		 staff3.setSpecialization("Windows");
		 staff3.setCh(centreHead);
		 
		 Set<Staff> stafflist=new HashSet<Staff>();
		 stafflist.add(staff1);
		 stafflist.add(staff2);
		 stafflist.add(staff3);
		 
		 centreHead.setStafflist(stafflist);
		 
		 /*session.save(staff1);
		 session.save(staff2);
		 session.save(staff3);*/
		 
		 session.save(centreHead);
		 
		 
		 
         
	     session.getTransaction().commit();  
	          
	     session.close();  
		 

	}

}
