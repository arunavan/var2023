package com.hcl.entity;

import javax.persistence.*;

@Entity
@Table(name="staff")
public class Staff {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int s_code;
	private String s_name;
	private String specialization;
	

	 @ManyToOne(cascade= CascadeType.ALL)
	 @JoinColumn(name="c_code")
   	private CentreHead ch;
	
	
	public Staff() {
		super();
		
	}
	
	public CentreHead getCh() {
		return ch;
	}
	
	

	public int getS_code() {
		return s_code;
	}
	public void setS_code(int s_code) {
		this.s_code = s_code;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public void setCh(CentreHead ch01) {
		this.ch=ch01;
		
	}

}
