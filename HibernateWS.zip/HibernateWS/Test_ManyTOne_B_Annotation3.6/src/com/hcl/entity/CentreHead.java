package com.hcl.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="centerhead")
public class CentreHead {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int c_code;
	private String c_name;
	
	private String centre_name;
	
	@OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="c_code") 
	private Set<Staff> stafflist=new HashSet<Staff>();
	
	public CentreHead() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getC_code() {
		return c_code;
	}
	public void setC_code(int c_code) {
		this.c_code = c_code;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public String getCentre_name() {
		return centre_name;
	}
	public void setCentre_name(String centre_name) {
		this.centre_name = centre_name;
	}

	public Set<Staff> getStafflist() {
		return stafflist;
	}

	public void setStafflist(Set<Staff> stafflist) {
		this.stafflist = stafflist;
	}
	
   
	

}
