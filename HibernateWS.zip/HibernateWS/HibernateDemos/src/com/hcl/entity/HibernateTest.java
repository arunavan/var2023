package com.hcl.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;

public class HibernateTest {

	

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
       

		UserDetails user1 = new UserDetails();
		user1.setUserId(4);
		user1.setUserName("Sara");
		
		UserDetails user2 = new UserDetails();
		user2.setUserId(5);
		user2.setUserName("Peter");
		
		UserDetails user3 = new UserDetails();
		user3.setUserId(6);
		user3.setUserName("Joe");
		
		
		session.beginTransaction();
		try {
			
			session.save(user1);//persistence state
			session.save(user2);//persistence state
			session.save(user3);//persistence state
			
			//employee.setEmpName("Pris");
			session.getTransaction().commit();
			System.out.println("****Data inserted successfully ****");
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

}
