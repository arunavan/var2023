package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class ScholarDeleteService {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Scholar scholar = (Scholar) session.get(Scholar.class, new Integer(4));
		if(scholar!=null){
		System.out.println("ScholarId: "+scholar.getScholarId()+"\tScholarName: "+scholar.getScholarName());
		session.beginTransaction();
		try{
			session.delete(scholar);
			scholar.setScholarName("Puspa");
			session.getTransaction().commit();
			
			scholar.setScholarName("Rupa");
		}catch(HibernateException e){
			e.printStackTrace();
		}
		
		}else{
			System.out.println("No data found");
		}
		
	}

}
