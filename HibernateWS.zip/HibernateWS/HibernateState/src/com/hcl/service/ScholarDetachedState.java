package com.hcl.service;

import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class ScholarDetachedState {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Scholar scholar = (Scholar) session.get(Scholar.class, new Integer(5));
		if(scholar!=null){
		System.out.println("ScholarId: "+scholar.getScholarId()+"\tScholarName: "+scholar.getScholarName());
		
		session.close();
		
		scholar.setScholarName("Keerthi");
		Session session2 =HibernateUtil.getSessionFactory().openSession();
		session2.beginTransaction();
		session2.update(scholar);
		scholar.setScholarName("Ram");
		session2.getTransaction().commit();
				
		}else{
			System.out.println("No data found");
		}

	}

}
