package com.hcl.service;

import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class ScholarMergeState {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Scholar scholar = (Scholar) session.load(Scholar.class, new Integer(5));
		
		if(scholar!=null){
			System.out.println("ScholarId: "+scholar.getScholarId()+"\tScholarName: "+scholar.getScholarName());
			
			session.close();
			scholar.setScholarName("Sowmya");
			
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			session2.beginTransaction();
			Scholar scholar1= (Scholar) session2.merge(scholar);
			scholar1.setScholarName("Rishav1");
			session2.getTransaction().commit();
			
		}else{
			System.out.println("No records found !!!");
		}
		

	}

}
