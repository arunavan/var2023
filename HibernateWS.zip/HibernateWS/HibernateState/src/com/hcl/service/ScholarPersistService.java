package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class ScholarPersistService {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		// �transient� state � Hibernate is NOT aware that it exists
		Scholar scholar = new Scholar();
  scholar.setScholarId(101);
		
		scholar.setScholarName("Praveen");
		
		Scholar scholar1 = new Scholar();
		scholar1.setScholarName("Seema");
		
		Scholar scholar2 = new Scholar();
		scholar2.setScholarName("Sriram");
		//transient
		session.beginTransaction();
		try{
			session.save(scholar);  //persistent
			session.save(scholar1);
			session.save(scholar2);
			scholar.setScholarName("Shailesh");
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
		}catch(HibernateException e){
			e.printStackTrace();
		}
		
session.close();
	//detached	
	}

}
