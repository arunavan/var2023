package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Module;
import com.hcl.entity.Student;

public class Many_TOne_Test_Unidirectional {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Module module = new Module();
		module.setModuleId(1001);
		module.setModuleName("Hibernate");
		
		Student student1 = new Student();
		student1.setStudentId(1);
		student1.setStudentName("Keerthi");
		student1.setModule(module);
		
		Student student2 = new Student();
		student2.setStudentId(2);
		student2.setStudentName("Nikhil");
		student2.setModule(module);
		
		session.beginTransaction();
		try{
			session.save(student1);
			session.save(student2);
			
			session.getTransaction().commit();
			System.out.println("Data inserted Successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally {
			if(session!=null){
				session.close();
			}
		}
		

	}

}
