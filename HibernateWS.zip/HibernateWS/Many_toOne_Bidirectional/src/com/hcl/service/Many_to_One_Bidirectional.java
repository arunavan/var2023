package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Player;
import com.hcl.entity.Team;

public class Many_to_One_Bidirectional {
	
	public static void main(String[] args) {
		
		Session session= HibernateUtil.getSessionFactory().openSession();
		
		Player player1= new Player();
		//player1.setPlayerNumber(10);
		player1.setPlayerName("Tendulkar");
		
		Player player2= new Player();
		//player2.setPlayerNumber(65);
		player2.setPlayerName("Virat");
		
		Player player3= new Player();
		//player3.setPlayerNumber(11);
		player3.setPlayerName("Dhoni");
		
		Set<Player>playerList =  new HashSet<Player>();
		playerList.add(player1);
		playerList.add(player2);
		playerList.add(player3);
		
		Team team = new Team();
		//team.setTeamId(1);
		team.setTeamName("India");
		
		//team.setPlayers(playerList);
		
		player1.setTeam(team);
		player2.setTeam(team);
		player3.setTeam(team);
		
		session.beginTransaction();
		try{
			
			//session.save(team);
			session.save(player1);
			session.save(player2);
			session.save(player3);
			
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		
	}

}
