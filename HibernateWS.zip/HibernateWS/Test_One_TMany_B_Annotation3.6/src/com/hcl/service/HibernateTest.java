package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.Player;
import com.hcl.entity.Team;

public class HibernateTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Team team = new Team();
		team.setName("Barcelona");

		Set<Player> playerList = new HashSet<Player>();
		Player p1 = new Player();
		p1.setName("Messi");
		p1.setTeam(team);

		Player p2 = new Player();
		p2.setName("Xavi");
		p2.setTeam(team);

		playerList.add(p1);
		playerList.add(p2);
		
		

		team.setPlayers(playerList);

		session.save(team);

		session.getTransaction().commit();

		session.close();

	}

}
