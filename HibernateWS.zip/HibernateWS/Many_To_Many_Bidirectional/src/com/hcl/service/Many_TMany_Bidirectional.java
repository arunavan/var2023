package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Group;
import com.hcl.entity.User;

public class Many_TMany_Bidirectional {

	public static void main(String[] args) {
		Session session= HibernateUtil.getSessionFactory().openSession();
		
		User user1 = new User();
		user1.setPassword("password1");
		user1.setMailId("user1@gmail.com");
		
		User user2 = new User();
		user2.setPassword("password2");
		user2.setMailId("user2@gmail.com");
		
		User user3 = new User();
		user3.setPassword("password3");
		user3.setMailId("user3@gmail.com");
		
		Set<User>usersList=new HashSet<User>();
		usersList.add(user1);
		usersList.add(user2);
		usersList.add(user3);
		
		Group group1 = new Group();
		group1.setGroupName("Admin Group");
		
		Group group2 = new Group();
		group1.setGroupName("Guest Group");
		
		Set<Group>groupList= new HashSet<Group>();
		groupList.add(group1);
		groupList.add(group2);
		
		user1.setGroups(groupList);
		user2.setGroups(groupList);
		user3.setGroups(groupList);
		
		group1.setUsers(usersList);
		group2.setUsers(usersList);
		
		session.beginTransaction();
		try{
			
			session.save(group1);
			session.save(group2);
			
			session.getTransaction().commit();
			System.err.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		
		
		
		
		
		
		

	}

}
