package com.hcl.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Group_Tab")
public class Group {
	@Id
	@GeneratedValue
	@Column(name="GROUP_ID")
	private int groupId;
	@Column(name="GROUP_Name")
	private String groupName;
	@ManyToMany(cascade=CascadeType.ALL,targetEntity=User.class)
	
	 @JoinTable(
	            name = "USERS_GROUPS",
	            joinColumns = @JoinColumn(name = "GROUP_ID"),
	            inverseJoinColumns = @JoinColumn(name = "USER_ID")
	    )

	private Set<User>users;
	
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Set<User> getUsers() {
		return users;
	}
	public void setUsers(Set<User> users) {
		this.users = users;
	}
	
	
	
	
}
