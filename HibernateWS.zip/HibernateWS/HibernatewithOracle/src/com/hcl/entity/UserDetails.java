package com.hcl.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
public class UserDetails {

	@Id
	@SequenceGenerator(name="seqUser", sequenceName="DB_seqUser" , initialValue=1000, allocationSize=1)
	@GeneratedValue(generator="seqUser", strategy=GenerationType.SEQUENCE)

	private int userId;
	private String userName;
	@Temporal(TemporalType.DATE)
	private Date doj;
	//@Transient
	private String nickName;
	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	

}
