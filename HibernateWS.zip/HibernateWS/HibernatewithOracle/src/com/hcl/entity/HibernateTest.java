package com.hcl.entity;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;

public class HibernateTest {

	

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
       

		UserDetails user1 = new UserDetails();
		//user1.setUserId(4);
		user1.setDoj(new Date());
		user1.setUserName("Sara");
		user1.setNickName("Sara1");
		
		UserDetails user2 = new UserDetails();
		//user2.setUserId(5);
		user2.setUserName("Peter");
		user2.setDoj(new Date());
		user2.setNickName("Peter1");
		
		UserDetails user3 = new UserDetails();
		//user3.setUserId(6);
		user3.setUserName("Joe");
		user3.setDoj(new Date());
		user3.setNickName("Joe1");
		
		session.beginTransaction();
		try {
			
			session.save(user1);//persistence state
			session.save(user2);//persistence state
			session.save(user3);//persistence state
			
			//employee.setEmpName("Pris");
			session.getTransaction().commit();
			System.out.println("****Data inserted successfully ****");
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

}
