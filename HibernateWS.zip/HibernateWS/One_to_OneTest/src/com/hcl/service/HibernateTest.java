package com.hcl.service;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.Department;
import com.hcl.entity.Employee;

public class HibernateTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Employee emp = new Employee();
		emp.setE_code(1001);
		emp.setEname("Ram");
		emp.setSal(45000);
		emp.setJoindate(new Date());
		
		Department department = new Department();
		department.setDeptno(1);
		department.setDeptname("Training");
		department.setEmployees(emp);
		

		

		session.save(department);

		session.getTransaction().commit();

		session.close();

	}

}
