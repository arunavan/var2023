package com.hcl.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Scholar;
import com.hcl.entity.Trainer;

public class Many_TMany_Test_Unidirection {

	public static void main(String[] args) {
		
		Session session=HibernateUtil.getSessionFactory().openSession();
		
		Scholar scholar1 = new Scholar();
		scholar1.setScholarId(1001);
		scholar1.setScholarName("Pushpa");
		
		Scholar scholar2 = new Scholar();
		scholar2.setScholarId(1002);
		scholar2.setScholarName("Jayanth");
		
		Scholar scholar3 = new Scholar();
		scholar3.setScholarId(1003);
		scholar3.setScholarName("Ram");
		
		Set<Scholar> scholarlist= new HashSet<Scholar>();
		scholarlist.add(scholar1);
		scholarlist.add(scholar2);
		scholarlist.add(scholar3);
		
		
		Trainer trainer1 = new Trainer();
		trainer1.setTrainerId(1);
		trainer1.setTrainerName("Uttam");
		trainer1.setScholars(scholarlist);
		
		Trainer trainer2 = new Trainer();
		trainer2.setTrainerId(2);
		trainer2.setTrainerName("Aruna");
		trainer2.setScholars(scholarlist);
		
		Trainer trainer3 = new Trainer();
		trainer3.setTrainerId(3);
		trainer3.setTrainerName("Rupa");
		trainer3.setScholars(scholarlist);
		
		session.beginTransaction();
		try{
			
			session.save(trainer1);
			session.save(trainer2);
			session.save(trainer3);
			
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		

	}

}
