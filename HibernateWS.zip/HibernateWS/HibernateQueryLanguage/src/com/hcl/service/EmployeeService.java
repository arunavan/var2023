package com.hcl.service;

import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.hcl.entity.Employee;

public class EmployeeService {
	
	public void insertEmployeeDetails(){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		/*Employee e = new Employee();
		e.setEmployeeId(1);
		e.setEmployeeName("Hari");
		e.setSalary(10000);
		e.setDateOfJoining(new Date());*/
		
		
		Employee e1 = new Employee();
		e1.setEmployeeId(2);
		e1.setEmployeeName("Joe");
		e1.setSalary(11000);
		e1.setDateOfJoining(new Date());
		
		
		Employee e2 = new Employee();
		e2.setEmployeeId(3);
		e2.setEmployeeName("Sam");
		e2.setSalary(12000);
		e2.setDateOfJoining(new Date());
		
		session.beginTransaction();
		try{
			
			//session.save(e);
			session.save(e1);
			session.save(e2);
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException ex){
			ex.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		
	}

	public List<Employee> viewAllEmployeeDetails() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		List employeeList=null;
		try{
		Query query = session.createQuery("select k from Employee k");
		employeeList = query.list();
		
		if (employeeList.isEmpty()) {
			System.out.println("No employee records available ");
		}
		}catch(HibernateException e){
			e.printStackTrace();
		}
		
		return employeeList;
	}

	public List<Object> getEmployeeById(int empId) {
		
		Session session= HibernateUtil.getSessionFactory().openSession();
		
		Query query = session.createQuery("select k.employeeName,k.salary from Employee k where k.employeeId=:eid");
		query.setParameter("eid",empId);
		List<Object>employeeList =query.list();
		
		if (employeeList.isEmpty()) {
			System.out.println("No employee records available ");
		}
		
		return employeeList;
			
		

	}

}
