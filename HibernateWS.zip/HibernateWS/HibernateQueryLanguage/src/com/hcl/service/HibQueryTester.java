package com.hcl.service;

import java.util.List;

import com.hcl.entity.Employee;

public class HibQueryTester {

	public static void main(String[] args) {
		
	EmployeeService service = new EmployeeService();
	
	//service.insertEmployeeDetails();
	
	/* List<Employee>empList=service.viewAllEmployeeDetails();
	 
	 for (Employee employee : empList) {
		System.out.print("Employee Id "+employee.getEmployeeId());
		System.out.print("\tEmployeeName "+employee.getEmployeeName()); 
		System.out.print("\tSalary "+employee.getSalary()); 
		System.out.print("\tDOJ "+employee.getDateOfJoining()); 
		System.out.println();
	}*/
	 
	 
	 List<Object>empList2=service.getEmployeeById(1);
	 Object[] obj= (Object[]) empList2.get(0);
	 String empName= (String) obj[0];
	 int salary =(int) obj[1]; 
	 
	 System.out.println("Employee Name "+empName+"\t employee Salary "+salary);
	}

}
