package com.hcl.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Scholar")
public class Scholar {
	@Id
	@SequenceGenerator(name="seq_scholar", sequenceName="DB_seq_scholar", initialValue=100,allocationSize=2)
	@GeneratedValue(generator="seq_scholar",strategy=GenerationType.SEQUENCE)
	private int scholarId;
	private String scholarName;
	

	public int getScholarId() {
		return scholarId;
	}
	public void setScholarId(int scholarId) {
		this.scholarId = scholarId;
	}
	public String getScholarName() {
		return scholarName;
	}
	public void setScholarName(String scholarName) {
		this.scholarName = scholarName;
	}
	
	
	
}
