package com.hcl.service;

import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class MergeState {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();	
		Scholar scholar = (Scholar) session.get(Scholar.class, new Integer(3));
		
		if(scholar!=null){
			System.out.println("ScholarId "+scholar.getScholarId()+"\tScholarName: "+scholar.getScholarName());
			
			session.close();
			scholar.setScholarName("Arvind");
			
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			session2.beginTransaction();
			Scholar scholar1=(Scholar) session2.merge(scholar);
			
			scholar1.setScholarName("Rupa");
			session2.getTransaction().commit();
			System.out.println("Data updated successfully");
		}
		

	}

}
