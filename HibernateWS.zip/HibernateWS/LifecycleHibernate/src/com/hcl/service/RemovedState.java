package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class RemovedState {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Scholar scholar= (Scholar) session.get(Scholar.class, 3);
		
		if(scholar!=null){
		
		System.out.println("Scholar Id: "+scholar.getScholarId()+"\tScholarName: "+scholar.getScholarName());
		session.beginTransaction();
		try{
			session.delete(scholar);
			
			scholar.setScholarName("Praveen");
			
			session.getTransaction().commit();
			
		}catch(HibernateException e){
			e.printStackTrace();
		}
				
		}else{
			System.out.println("No records found!");
		}
	}

}
