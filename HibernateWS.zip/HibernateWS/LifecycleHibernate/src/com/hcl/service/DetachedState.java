package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class DetachedState {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Scholar scholar = (Scholar) session.get(Scholar.class, 3);

		if (scholar != null) {
			
			session.beginTransaction();
			System.out.println("Scholar Id: " + scholar.getScholarId() + "\tScholarName: " + scholar.getScholarName());
			
			session.close();
			
			scholar.setScholarName("Keerthi");
			
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			session2.beginTransaction();
			session2.update(scholar);
			
			scholar.setScholarName("Prithivi");
			session2.getTransaction().commit();

		} else {
			System.out.println("No records found!");
		}
	}

}
