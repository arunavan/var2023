package com.hcl.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hcl.entity.Scholar;

public class PersistenceState {

	public static void main(String[] args) {
		
	Session session = HibernateUtil.getSessionFactory().openSession();
	//transient state
	Scholar s1 = new Scholar();
	s1.setScholarName("Sriram");
	
	Scholar s2 = new Scholar();
	s2.setScholarName("Ram");
	
	Scholar s3 = new Scholar();
	s3.setScholarName("Rishav");
	
	session.beginTransaction();
	try{
		
		session.saveOrUpdate(s1);
		session.saveOrUpdate(s2);
		session.saveOrUpdate(s3);
		
		s1.setScholarName("Sudha");
		
		session.getTransaction().commit();
		
		s2.setScholarName("Pushpa");
		
		
		System.out.println("Data inserted successfully");
		
	}catch(HibernateException e){
		e.printStackTrace();
	}finally{
		if(session!=null){
			session.close();
		}
	}
	

	}

}
