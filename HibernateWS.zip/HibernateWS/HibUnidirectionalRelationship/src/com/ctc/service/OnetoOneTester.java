package com.ctc.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Employee1;
import com.cts.entity.ParkingSpace;

public class OnetoOneTester {

private static final SessionFactory sessionFactory;
	
	static {

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}

	      catch (Throwable ex) {

			System.err.println("Initial SessionFactory creation failed." + ex);

			throw new ExceptionInInitializerError(ex);

		}
	
	}
	
	private static Session ses;
	private static Transaction ts;
	public static void main(String[] args) {
		try{
		ses= sessionFactory.openSession();
		ts=ses.beginTransaction();
		
		ParkingSpace space = new ParkingSpace();
		space.setParkingId(1);
		space.setBuildingName("MBP");
		
		Employee1 employee= new Employee1();
		employee.setEmpId(1003);
		employee.setName("Ram");
		employee.setSpace(space);
		
		ts.begin();
		ses.save(employee);
		ts.commit();
		
		System.out.println("Data persisted successfully");
		
		
		}catch(HibernateException e){
			e.printStackTrace();
		}
		
	}

}
