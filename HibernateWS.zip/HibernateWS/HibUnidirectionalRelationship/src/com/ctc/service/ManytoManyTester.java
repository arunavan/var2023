package com.ctc.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Engineer;
import com.cts.entity.Project;

public class ManytoManyTester {

private static final SessionFactory sessionFactory;
	
	static {

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}

	      catch (Throwable ex) {

			System.err.println("Initial SessionFactory creation failed." + ex);

			throw new ExceptionInInitializerError(ex);

		}
	
	}
	
	private static Session ses;
	private static Transaction ts;
	public static void main(String[] args) {
		
		try{
			
			ses= sessionFactory.openSession();
			ts=ses.beginTransaction();
			
			List<Project> projects= new ArrayList<Project>();
			
			Project project1 = new Project();
			project1.setProjectId(1111);
			project1.setProjectName("ABC");
			
			Project project2 = new Project();
			project2.setProjectId(2222);
			project2.setProjectName("XYZ");
			
			projects.add(project1);
			projects.add(project2);
			
			Engineer eng1= new Engineer();
			eng1.setEmpId(1001);
			eng1.setName("David");
			eng1.setProjects(projects);
			
			Engineer eng2= new Engineer();
			eng2.setEmpId(1002);
			eng2.setName("Sam");
			eng2.setProjects(projects);
			
			ts.begin();
			ses.saveOrUpdate(eng1);
			ses.saveOrUpdate(eng2);
			
			ts.commit();
					
			System.out.println("Data saved successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}
		
	}

}
