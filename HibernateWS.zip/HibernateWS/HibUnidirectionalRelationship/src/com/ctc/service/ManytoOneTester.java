package com.ctc.service;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Department;
import com.cts.entity.Faculty;

public class ManytoOneTester {
	private static SessionFactory factory;
	static{
		try{
			factory= new Configuration().configure().buildSessionFactory();
			
		}catch(Throwable ex){
			System.out.println("Error "+ex);
			throw new ExceptionInInitializerError();
		}
		
	}
	
	private static Session  session;
	private static Transaction tx;

	public static void main(String[] args) {
	
		try{
			
			session= factory.openSession();
			tx=session.beginTransaction();
			
			Department department= new Department();
			department.setDeptId(3);
			department.setDeptName("Retail");
			
			Faculty faculty1= new Faculty();
			faculty1.setEmpId(1007);
			faculty1.setName("Ram");
			faculty1.setDepartment(department);
			
			Faculty faculty2= new Faculty();
			faculty2.setEmpId(1008);
			faculty2.setName("Rita");
			faculty2.setDepartment(department);
			
			tx.begin();
			
			session.save(faculty1);
			session.save(faculty2);
			tx.commit();
			
			
			System.out.println("Transaction Complete");
			
			
			
		}catch(HibernateException e){
			e.printStackTrace();
		}
	}

}
