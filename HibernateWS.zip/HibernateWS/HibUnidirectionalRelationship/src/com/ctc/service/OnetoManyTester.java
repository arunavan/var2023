package com.ctc.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Lecturer;
import com.cts.entity.Subject;

public class OnetoManyTester {

private static final SessionFactory sessionFactory;
	
	static {

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}

	      catch (Throwable ex) {

			System.err.println("Initial SessionFactory creation failed." + ex);

			throw new ExceptionInInitializerError(ex);

		}
	
	}
	
	private static Session ses;
	private static Transaction ts;
	public static void main(String[] args) {
		
		try{
			
			ses= sessionFactory.openSession();
			ts=ses.beginTransaction();
			
			List<Subject>subjects= new ArrayList<Subject>();
			
			Subject subject1= new Subject();
			subject1.setSubjectId(101);
			subject1.setSubjectName("sanskrit");
			
			
			Subject subject2= new Subject();
			subject2.setSubjectId(102);
			subject2.setSubjectName("Bengali");
			
					
			
			Subject subject3= new Subject();
			
			subject3.setSubjectId(103);
			subject3.setSubjectName("Marati");
			
			
			subjects.add(subject1);
			subjects.add(subject2);
			subjects.add(subject3);
			
			
			Lecturer lecturer= new Lecturer();
			lecturer.setLecturerId(1111);
			lecturer.setLecName("Uttam");
			lecturer.setSubjects(subjects);
			
			ts.begin();
			ses.save(lecturer);
			ts.commit();
			
			System.out.println("Data saved successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}
		
	}

}
