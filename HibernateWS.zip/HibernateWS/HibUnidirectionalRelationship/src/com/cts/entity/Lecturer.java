package com.cts.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class Lecturer {
	@Id
	private int lecturerId;
	private String lecName;
	
	
	@OneToMany(cascade=CascadeType.ALL,targetEntity=Subject.class )
	//@Fetch(FetchMode.SELECT)
	//@Fetch(FetchMode.JOIN)
	//@Fetch(FetchMode.SUBSELECT)
	//@BatchSize(size = 10)
  	@JoinTable(name="Lect_Subjects")
	private List<Subject>subjects;


	

	public int getLecturerId() {
		return lecturerId;
	}

	public void setLecturerId(int lecturerId) {
		this.lecturerId = lecturerId;
	}

	public String getLecName() {
		return lecName;
	}

	public void setLecName(String lecName) {
		this.lecName = lecName;
	}

	public List<Subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}

	
	
	

}
