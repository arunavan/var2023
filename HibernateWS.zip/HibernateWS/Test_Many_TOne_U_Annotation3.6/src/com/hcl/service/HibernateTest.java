package com.hcl.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hcl.entity.Customers;
import com.hcl.entity.Vendor;

public class HibernateTest {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
		 Session session = sessionFactory.openSession();
		 session.beginTransaction();  
		 
		 Vendor vendor =new Vendor();
		 vendor.setVendorName("Filpkart");
		 
		 Customers customer1 = new Customers();
		 customer1.setCustomerName("Peter");
		 customer1.setVendor(vendor);
		 
		 Customers customer2 = new Customers();
		 customer2.setCustomerName("Joe");
		 customer2.setVendor(vendor);
		 
		 session.save(customer1);
		 session.save(customer2);
		 
		 
		 
         
	     session.getTransaction().commit();  
	          
	     session.close();  
		 

	}

}
