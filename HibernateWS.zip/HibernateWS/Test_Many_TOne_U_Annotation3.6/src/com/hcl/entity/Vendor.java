package com.hcl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Vendor")
public class Vendor {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "vendorId")
	private int vendorId;
 
	@Column(name = "vendorName", length=10)
	private String vendorName;
 
	public int getVendorId() {
		return vendorId;
	}
 
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
 
	public String getVendorName() {
		return vendorName;
	}
 
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

}
