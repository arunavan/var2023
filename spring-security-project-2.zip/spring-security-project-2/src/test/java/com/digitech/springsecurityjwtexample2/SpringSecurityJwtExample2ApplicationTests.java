package com.digitech.springsecurityjwtexample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityJwtExample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
